import { Routes, Route, useNavigate } from "react-router-dom";
import Login from "./auth/Login";
import SignUp from "./auth/Singup"; // Corrected typo in filename
import AppBar from "./componets/AppBar"; // Corrected typo in filename
import { ForgotPassword } from "./auth/ForgotPassword"; // Removed braces
import { ResetPassword } from "./auth/ResetPassword"; // Removed braces
import PrivateRoute from "./PrivateRoute";
import { useEffect, useState } from "react";
import 'rsuite/dist/rsuite.min.css';
import { refreshToken } from "./functions/refreshToken";
import UserProfile from "./componets/userProfile/USerProfile";
import { LoadingOutlined } from '@ant-design/icons';
import { Flex, Spin } from 'antd';


const App = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);


  useEffect(() => {
    const checkToken = async () => {
      const sessionToken = sessionStorage.getItem("accessToken");
      const localToken = localStorage.getItem("accessToken");

      if (!sessionToken && localToken) {
        await refreshToken(navigate);
        if (window.location.pathname.startsWith('/dashboard')) {
          navigate('/dashboard');
        } else if (!sessionToken && !localToken) {
          navigate('/');
        }
      }
      setLoading(false);
    };

    checkToken();
  }, [navigate]);





  if (loading) {
    return <Flex gap="middle" className="mt-0 flex justify-center items-center relative top-80">
      <Spin indicator={<LoadingOutlined style={{ fontSize: 48 }} spin />} className="text-5xl " />
    </Flex>;
  }

  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/dashboard" element={<PrivateRoute><AppBar /></PrivateRoute>} />
      <Route path="/signup" element={<SignUp />} /> {/* Not protected */}
      <Route path="/forgotpassword" element={<ForgotPassword />} /> {/* Not protected */}
      <Route path="/resetpassword" element={<ResetPassword />} /> {/* Not protected */}
      <Route path="/profile" element={<PrivateRoute><UserProfile /></PrivateRoute>} />
    </Routes>
  );
};

export default App;
