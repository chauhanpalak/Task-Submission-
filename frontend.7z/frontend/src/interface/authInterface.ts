export  interface Data {
    phone: string;
    fullname: string;
    username: string;
    email: string;
  
    password: string;
  }